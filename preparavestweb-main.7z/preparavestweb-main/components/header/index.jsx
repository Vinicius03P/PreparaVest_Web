import React, { useState, useEffect } from "react";
import { Text, View, Image, Pressable } from "react-native";
import { style } from "./style";
import { useNavigation, StackActions } from '@react-navigation/native';
import * as Font from 'expo-font';
import KollektifBold from '../../assets/fonts/Kollektif-Bold.ttf';
import Kollektif from '../../assets/fonts/Kollektif.ttf';
import { AvatarContext } from "../avatarcomp/index.jsx";
import AsyncStorage from '@react-native-async-storage/async-storage';
import GetImage from "./avatarImages.jsx";

export default function Cabecalho() {
  const navigation = useNavigation();
  const [fontsLoaded, setFontsLoaded] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState('false'); // Estado de exemplo para autenticação
  const [email, setEmail] = useState('');
  const [id, setId] = useState('')
  const [avatarId, setAvatarId] = useState(require('../../assets/avatares/0.png'))

  // Carregamento de fontes
  useEffect(() => {
    async function loadFonts() {
      await Font.loadAsync({
        KollektifBold: KollektifBold,
        Kollektif: Kollektif,
      });
      setFontsLoaded(true);
    }

    async function loadStorage(){
      const teste = await AsyncStorage.getItem('verificaLogin')
      const email = await AsyncStorage.getItem('email')
      const id = await AsyncStorage.getItem('id')
      const avatarId = await AsyncStorage.getItem('avatarId')
      
      if(teste && email && id && avatarId){
        setEmail(email)
        setId(id)
        setIsAuthenticated(teste)
        const avatar = GetImage(`${avatarId}.png`)
        setAvatarId(avatar)
      }
    }
  
    loadFonts()
    loadStorage()
  }, []);


  if (!fontsLoaded) {
    return (
      <View>
        <Text>Loading...</Text>
      </View>
    );
  };

  return (
    <View style={style.cabecalho}>
      <Image style={style.ImagemLogo} source={require('../../assets/Professores/logopreparavest.jpeg')} />

      <View style={style.subtitulo}>
        <Pressable onPress={() => navigation.dispatch(StackActions.replace("Home"))}>
          <Text style={{ fontSize: 22 }}>Home</Text>
        </Pressable>
        <Pressable onPress={() => navigation.dispatch(StackActions.replace("Pagina Enem"))}>
          <Text style={{ fontSize: 22 }}>Provas</Text>
        </Pressable>
        <Pressable onPress={() => navigation.dispatch(StackActions.replace("Informacoes"))}>
          <Text style={{ fontSize: 22 }}>Informações Gerais</Text>
        </Pressable>
        <Pressable onPress={() => navigation.dispatch(StackActions.replace("Conteudo relevante"))}>
          <Text style={{ fontSize: 22 }}>Conteúdo Relevante</Text>
        </Pressable>
        <Pressable onPress={() => navigation.dispatch(StackActions.replace("Dicas"))}>
          <Text style={{ fontSize: 22 }}>Dicas de Estudos</Text>
        </Pressable>
        <Pressable onPress={() => navigation.dispatch(StackActions.replace("Estatisticas"))}>
          <Text style={{ fontSize: 22 }}>Estatísticas</Text>
        </Pressable>
      </View>

      {/* Ícone do avatar que abre o modal de perfil */}
      {isAuthenticated == 'true' ? 
        <Pressable onPress={() => navigation.navigate("Profile")}>
          <Image source={avatarId} style={style.avatarIcon} />
        </Pressable>
        : <Pressable onPress={()=>{
          navigation.push('Login')
        }}>
          Entrar
        </Pressable>}
    </View>
  );
}
